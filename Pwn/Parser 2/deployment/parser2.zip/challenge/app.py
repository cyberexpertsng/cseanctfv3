from flask import Flask, request, render_template
import os
import subprocess
from werkzeug.utils import secure_filename
import uuid

app = Flask(__name__)

UPLOAD_FOLDER = "/tmp/files/"
MAX_FILE_SIZE = 5 * 1024 * 1024
ALLOWED_EXTENSIONS = {"bmp"}

app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET", "POST"])
def upload_file():
    if request.method == "POST":
        if "file" not in request.files:
            return render_template("index.html", message="No file part")

        file = request.files["file"]

        if file.filename == "":
            return render_template("index.html", message="No selected file")

        if not allowed_file(file.filename):
            return render_template("index.html", message="Only BMP files are allowed")

        filename = f"{uuid.uuid4().hex}.bmp"
        filepath = os.path.join(UPLOAD_FOLDER, filename)

        try:
            file.save(filepath)
        except Exception as e:
            return render_template("index.html", message=f"Save error: {e}")

        try:
            result = subprocess.run(
                ["./verify", filename],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            return render_template("result.html", success=(result.returncode == 0))

        except Exception as e:
            return render_template("index.html", message=f"Verifier error: {e}")

    return render_template("index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)