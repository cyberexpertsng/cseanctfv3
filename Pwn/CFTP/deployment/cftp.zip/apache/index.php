<?php
// wtf is php??
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Moving Ball</title>
    <style>
        body {
            margin: 0;
            background: #111;
            overflow: hidden;
        }
        canvas {
            display: block;
        }
    </style>
</head>
<body>

<canvas id="canvas"></canvas>

<script>
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const ball = {
    x: canvas.width / 2,
    y: canvas.height / 2,
    r: 20,
    dx: 3.5,
    dy: 2.8
};

function drawBall() {
    ctx.beginPath();
    ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
    ctx.fillStyle = "cyan";
    ctx.fill();
    ctx.closePath();
}

function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ball.x += ball.dx;
    ball.y += ball.dy;

    if (ball.x + ball.r > canvas.width || ball.x - ball.r < 0) {
        ball.dx *= -1;
    }

    if (ball.y + ball.r > canvas.height || ball.y - ball.r < 0) {
        ball.dy *= -1;
    }

    drawBall();
    requestAnimationFrame(update);
}

update();

window.addEventListener("resize", () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});
</script>

</body>
</html>